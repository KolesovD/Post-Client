**Project Description**
A small, efficient, and working mime parser library written in c#.

A recurring need for me and my customers is some kind of integration with email. For instance an integrator that imports email into some kind of bug tracking system. When developing an integrator like this you need to import the email, extract the essential information like subject, message body and attachments, and create the bug/task/issue based on these values. The core of this problem is to interpret the email message so that the values you put into the receiving system is readable and valuable.

I've used several open source mime parsers before, but they all either fail on one kind of encoding or the other, or miss some crucial information. That's why I decided to finally have a go at the problem myself.

In addition to trying to make the parser standard compliant, after a few attempts I also decided that the parser should populate the System.Net.Mail.MailMessage object, instead of making my own class structure. This makes it very easy to forward the parsed messages to other recipients, and is familiar to those that has made smtp mail sending integration before. This made the parser a bit more complex than first intended. Especially the inline images in html text was a bit tricky to get to work. 

I have tested the parser on a few hundred test emails with various encodings and attachments, and they all work now, but please try to challenge the code and send me examples on emails that the parser handles incorrectly, (or makes it crash...)

There is a crude pop3 client included in the library as well, just for testing purposes, but you can of course use this as well if you so desire. There are probably a few dozen other pop3 client implementations that are better though...

